import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# -------------------------
# PAGE CONFIG
# -------------------------
st.set_page_config(page_title="Fraud Detection Dashboard", layout="wide")

st.title("💳 Credit Card Fraud Detection Dashboard")

# -------------------------
# LOAD DATA
# -------------------------
data = pd.read_csv("../data/fraud_data.csv")

# -------------------------
# SIDEBAR FILTERS (Power BI style)
# -------------------------
st.sidebar.header("Filters")

class_filter = st.sidebar.selectbox(
    "Select Transaction Type",
    ["All", "Normal", "Fraud"]
)

filtered_data = data.copy()

if class_filter == "Normal":
    filtered_data = data[data["Class"] == 0]

elif class_filter == "Fraud":
    filtered_data = data[data["Class"] == 1]

# -------------------------
# KPI CARDS
# -------------------------
total_transactions = len(filtered_data)
fraud_transactions = filtered_data["Class"].sum()
normal_transactions = total_transactions - fraud_transactions
fraud_percentage = (fraud_transactions / total_transactions) * 100 if total_transactions > 0 else 0

col1, col2, col3, col4 = st.columns(4)

col1.metric("Total Transactions", total_transactions)
col2.metric("Fraud Transactions", fraud_transactions)
col3.metric("Normal Transactions", normal_transactions)
col4.metric("Fraud %", f"{fraud_percentage:.2f}%")

st.markdown("---")

# -------------------------
# CHARTS (SIDE BY SIDE)
# -------------------------
col1, col2 = st.columns(2)

# Fraud vs Normal Chart
with col1:
    st.subheader("Fraud vs Normal Transactions")

    fig, ax = plt.subplots()
    filtered_data["Class"].value_counts().plot(kind="bar", ax=ax)

    plt.xlabel("Class (0=Normal, 1=Fraud)")
    plt.ylabel("Count")

    st.pyplot(fig)

# Amount Distribution
with col2:
    st.subheader("Transaction Amount Distribution")

    fig2, ax2 = plt.subplots()
    sns.histplot(filtered_data["Amount"], bins=40, ax=ax2)

    st.pyplot(fig2)

st.markdown("---")

# -------------------------
# DATA TABLE (BOTTOM)
# -------------------------
st.subheader("Transaction Details")

st.dataframe(filtered_data.head(100))

st.markdown("---")

# -------------------------
# FRAUD PREDICTION SECTION
# -------------------------
st.subheader("Fraud Prediction")

amount = st.number_input("Enter Transaction Amount")

if st.button("Predict"):

    if amount > filtered_data["Amount"].mean():
        st.warning("⚠ High Amount Transaction (Possible Fraud)")
    else:
        st.success("✓ Normal Transaction")